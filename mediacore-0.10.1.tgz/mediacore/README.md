# mediacore

A WebRTC SFU that speaks the LiveKit protocol, and the front end that goes with
it. Two workloads out of one image:

- **sfu** — signalling on TCP `7880` (`/rtc`, `/rtc/validate`, `/healthz`, the
  room service under `/twirp/...` and a generated API page at `/swagger`), and
  **all media on one UDP port**, `7882` by default. One port, not a range.
- **front** — the page and the token endpoint, HTTP on `8080`.

Both are optional. Turn the front end off to put your own in front of the SFU;
turn the SFU off to run the page against one somewhere else.

```
                        the cluster
    ┌──────────────────────────────────────────────────┐
    │  gateway (Envoy) or ingress controller  443/tcp  │
    │    ├── /rtc*, /twirp*  ──►  sfu   :7880          │
    │    └── /                ──►  front :8080         │
    │                                                  │
    │  sfu  7882/udp  ── on the node, not through the  │
    │                    gateway and not through a     │
    │                    Service unless you ask for it │
    └──────────────────────────────────────────────────┘
          ▲                                ▲
          │ https page, wss signalling     │ microphone audio
          └──────────── browser ───────────┘
```

## Before anything else: build the image

Nothing publishes a mediacore image. `image.repository` has no default and the
chart refuses to render without one.

```console
git clone https://github.com/GlobalArtInc/mediacore
cd mediacore
podman build -t registry.example.com/mediacore:0.1.0 .
podman push registry.example.com/mediacore:0.1.0
```

The `Dockerfile` at the root builds both binaries into one image. The chart runs
the SFU from the image's own CMD and names `mediacore-front` for the front end.
It also expects `envsubst` in the image, which that Dockerfile installs
(`gettext-base`) for its own start script.

## Install

```console
helm repo add globalart https://globalartinc.github.io/helm-charts
helm install meet globalart/mediacore \
  --set image.repository=registry.example.com/mediacore \
  --set-string auth.apiSecret="$(openssl rand -hex 32)" \
  --set route.host=meet.example.com \
  --set route.tls.secretName=wildcard-example-com
```

That is the whole minimal deployment: an SFU on the node's network advertising
the node's address, a front end behind it, and one hostname carrying both.

## The three things that will bite you

### 1. Media is UDP and goes through neither the gateway nor an Ingress

An `HTTPRoute` carries HTTP, and so does an `Ingress`. Media is UDP, it is
addressed to the SFU directly, and the pod IP is not routable from a browser, so
something has to put that socket where clients can reach it. The chart offers
three ways and defaults to the first:

| | what it does | what it costs |
|---|---|---|
| `sfu.hostNetwork: true` (default) | the pod shares the node's netns and binds the media port on the node | the pod also takes `sfu.ports.signalling` on the node, so two releases collide there; PodSecurity `baseline` forbids it; needs `dnsPolicy: ClusterFirstWithHostNet`, which the chart sets |
| `sfu.hostPort: true` | only the media port is published on the node | hostPort is the CNI's job and CNIs differ — Cilium needs its host-port support on, portmap-based ones add a NAT that can rewrite the source port |
| `sfu.mediaService.enabled: true` | an ordinary UDP Service | a LoadBalancer needs a provider that forwards UDP; a NodePort lands on a *different* port number, and then you must advertise `<node ip>:<node port>` explicitly |

Whichever you pick, `udp/7882` has to be open to the clients in the node
firewall and in any cloud security group, **as UDP**. A TCP rule for that port
does nothing at all.

### 2. The advertised address is what decides whether anyone hears anything

The SFU writes an address into every ICE candidate, and that is where browsers
send their microphones. Get it wrong and nothing looks broken: people join, the
participant list is right, the mute button works, and the room is silent. No
error is logged, because packets sent to an unreachable address look exactly
like packets a firewall ate.

By default the chart reads the node's own address from the downward API
(`status.hostIP`) into the config at pod start, which is correct for
`hostNetwork` and for `hostPort`. It stops being correct the moment something
in front of the pod changes the address or the port:

```yaml
sfu:
  advertise:
    fromNodeIP: false
    addresses:
      - 203.0.113.7        # a load balancer that keeps the port
      - 198.51.100.9:31882 # a NodePort, or NAT that renumbers it
```

Addresses only — ICE candidates carry addresses, never names, and the server
refuses a hostname at startup. Both may be on at once: the node's address for
clients inside the network, a public one for everybody else.

What the server settled on is in its own log, and it is the first thing to read
when a room is silent:

```console
kubectl logs deploy/<release>-mediacore-sfu | grep "media transport ready"
... media transport ready local=0.0.0.0:7882 advertise=[203.0.113.7:7882] ...
```

Ignore the `ice socket bound` line just above it: that one reports the socket's
own view (`0.0.0.0`) and not what clients are told.

### 3. One replica, and a restart ends every call

mediacore is a single node by construction. Rooms, participants and every track
live in the memory of one process, and the two RPCs that would move a
participant between nodes — `ForwardParticipant` and `MoveParticipant` — answer
`unimplemented` on purpose. Two replicas behind one Service put half of a room
on each pod, and neither half hears the other with nothing in any log to say
why, so `sfu.replicaCount` other than 1 fails the render. If one process is not
enough, run separate releases and decide in your own application which room
lives where.

For the same reason the SFU rolls with `strategy: Recreate` and **every upgrade
of it ends every meeting in progress** — an image change, a config change, a
node drain. There is no resume: the server tells a reconnecting client that its
session is gone. Roll it when nobody is in a room, and note that the config
checksum is on the pod, so `helm upgrade --set sfu.config...` restarts the
process too. The front end has none of these limits: it holds nothing, it never
talks to the SFU, and it scales and rolls freely.

## Publishing

Two ways, and they are alternatives rather than layers. `route.enabled` (the
default) renders a `ListenerSet` on the shared gateway and an `HTTPRoute` in the
same shape as the [`route`](../route) chart; `ingress.enabled` renders one
`Ingress` instead, for a cluster that has no Gateway API. Either way it is one
hostname with `/rtc` and `/twirp` on the SFU and everything else on the front
end — the split is written once in the chart and both objects read it, so they
cannot come to disagree about which request belongs to which backend.

**One hostname, deliberately.** The front end may only be handed a scheme and a
bare host for the WebSocket — it appends `/rtc` itself and refuses a URL with a
path — and a page served from one origin may not open a WebSocket to another
without the browser refusing it silently. Splitting them across two names is the
one arrangement that cannot work.

No `Certificate` is created by default: wildcards are already issued for the
cluster's domains, so `route.tls.secretName` names an existing Secret and the
chart adds the `ReferenceGrant` the gateway needs to read it from this
namespace. Set `route.tls.certificate.enabled` only for a host no wildcard
covers.

`/swagger` is not published (`route.swagger: false`). The page carries no token
and leaks nothing, but its Try-it-out buttons act on the real room service —
`DeleteRoom` really does hang up on everyone — so it is left to a port-forward:

```console
kubectl port-forward svc/<release>-mediacore-sfu 7880:7880
```

With it off, a request to `/swagger` falls through to the front end and answers
404, which reads exactly like a broken build. That is expected.

Publishing some other way — neither of these — is `route.enabled: false` with
`ingress.enabled: false`, and then `front.wsUrl` has to be set by hand.

### With an Ingress

```console
helm install meet globalart/mediacore \
  --set image.repository=registry.example.com/mediacore \
  --set-string auth.apiSecret="$(openssl rand -hex 32)" \
  --set route.enabled=false \
  --set ingress.enabled=true \
  --set ingress.host=meet.example.com \
  --set ingress.className=nginx \
  --set ingress.tls.secretName=wildcard-example-com
```

`ingress.host` defaults to `route.host`, so a values file that already names the
host does not name it twice. `route.swagger` governs `/swagger` here too: one
split, one switch. TLS is an existing Secret **in this namespace** — an Ingress
reads no Secret from anywhere else, so a shared wildcard has to be copied here
(reflector, external-secrets, by hand) and there is no `ReferenceGrant` to make.
Leaving `ingress.tls.secretName` empty renders no `tls` block and serves the
name over plain http, on which browsers refuse to hand out a microphone at all
outside localhost.

**It does not carry media.** Nothing in this section changes anything in
["Media is UDP"](#1-media-is-udp-and-goes-through-neither-the-gateway-nor-an-ingress)
above:
`udp/7882` still goes straight to the node, `sfu.hostNetwork` still decides how
it gets there, and `sfu.advertise` still decides whether anyone hears anything.
An Ingress publishes the page and the signalling WebSocket. That is all it can
do.

**The WebSocket dies on the default timeouts.** ingress-nginx closes an upstream
connection that has been quiet for 60 seconds, and a signalling WebSocket
carries nothing while a call is simply going on, so the room works for about a
minute and then drops everybody at once — with nothing in the SFU's log, because
from its side the proxy closed the connection and that is not an error. The
chart ships the fix as a default:

```yaml
ingress:
  annotations:
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
```

Those are ingress-nginx annotations and nothing else reads them. They are an
idle timeout rather than a limit on the length of a call — any signalling
traffic resets it — and on another controller they are inert, so set that
controller's own equivalent instead: Traefik has it on the entrypoint
(`respondingTimeouts`) and not on an annotation, an AWS ALB has
`alb.ingress.kubernetes.io/load-balancer-attributes:
idle_timeout.timeout_seconds=3600` over a default of 60, GKE takes a
`BackendConfig` with `timeoutSec` over a default of 30, and the two HAProxy
controllers each spell a tunnel timeout their own way. Prove it with a call that
sits quiet for two minutes; joining, talking and leaving never reproduces it.

**Both at once, on one name, is allowed.** It is how a live deployment moves
from the gateway to an ingress controller: both publish the hostname with the
same paths, you move the DNS record, then you turn the old one off. Two
*different* names fails the render instead, because the front end is built with
exactly one WebSocket URL and whoever arrived on the other name would get a page
whose WebSocket the browser refuses in silence. (With `front.enabled: false`
there is no page and no such URL, so two names are allowed there.)

## Names

Objects are named after the release, with the chart's name appended only when
the release name does not already contain it. A release called `mediacore` gets
`mediacore-sfu`, not `mediacore-mediacore-sfu`; a release called `calls` gets
`calls-mediacore-sfu`.

This is not only tidiness. The SFU's `node_id` is its pod name, and that name is
written into every session record and every row of the recording queue, so the
doubled form was visible in the data and in every log line.

**Renaming a release that is already installed replaces every object in it.**
The StatefulSet, the Services, the ConfigMap and the route are deleted and
recreated under the new names; the claims made by `volumeClaimTemplates` are not
Helm's to delete, so they are left behind under the old names holding whatever
was on them. And because the pod's name changes, so does `node_id`: recordings
still on the disk are owned by a node that no longer exists. Do this with
nothing being recorded and `stuck_recording_work` at zero, and clean up the old
claims by hand afterwards.

## Secrets

`auth.apiKey` is an identifier — the `iss` of every token and the name the
secret is looked up under. `auth.apiSecret` is what signs them, at least 32
characters (`openssl rand -hex 32`); the front end refuses to start below that,
so a shorter one gives you an SFU that runs and a front end that crash-loops.

There is no default secret and the chart will not render a Secret without a
value somebody chose. Either pass `auth.apiSecret`, or point
`auth.existingSecret` at a Secret you manage and let `auth.secretKeys` name the
keys in it.

The same Secret carries the two other credentials the SFU may need, on the same
terms: `auth.postgresUrl` when it keeps meetings in a database, and
`auth.s3AccessKeyId` / `auth.s3SecretAccessKey` when it records. Neither is read
unless the setting that needs it is on, and neither is ever in the ConfigMap.

**With `auth.existingSecret` the chart cannot check any of this.** It cannot see
inside a Secret it did not make, so the refusals above do not fire and a Secret
missing `postgres-url` renders, installs and reports success. What you get is a
pod that will not start. The env vars are declared `optional`, so the failure is
the init container saying which Secret and which key rather than a
`CreateContainerConfigError` with no logs at all — but on a Deployment whose
strategy is `Recreate`, the old pod is gone by then. Turning either feature on
against an existing Secret means checking its keys yourself first:

```console
kubectl -n <ns> get secret <name> -o jsonpath='{.data}' | tr ',' '\n' | cut -d'"' -f2
```

Anyone holding the secret can mint a token for any room and any identity. It
reaches the SFU through the environment of an init container and is substituted
into the config file there — it is never in the ConfigMap, and the rendered file
lives in a memory-backed `emptyDir`.

## Keeping meetings, and recording them

Out of the box the SFU writes one JSON file per meeting to the volume in
`persistence`, and records nothing. That is the arrangement one process wants,
and it is the reason `sfu.replicaCount` is refused above one.

A database replaces the directory:

```yaml
auth:
  postgresUrl: postgres://mediacore:...@db.example.com:5432/mediacore
sfu:
  config:
    sessions:
      postgres:
        enabled: true
```

The server migrates the schema itself, under an advisory lock, so several
processes starting at once is safe. The url is not a chart setting -- it carries
a password -- so it goes in the Secret, like `auth.apiSecret`, and is
substituted into the config file inside the pod.

Recording needs that database and a bucket. An upload is a row several processes
claim, which a directory of files cannot be, so the chart refuses the pairing
rather than letting the server refuse it on the node:

```yaml
auth:
  s3AccessKeyId: ...
  s3SecretAccessKey: ...
recordings:
  enabled: true
  storageClass: csi-rbd-sc
  size: 50Gi
sfu:
  config:
    recording:
      # true records every meeting; false still records the rooms that ask for
      # it themselves, with {"sessionPolicy": {"record": true}} in the metadata
      # they were created with.
      enabled: true
      s3:
        endpoint: https://storage.example.com
        region: ru-1
        bucket: mediacore
        path_style: true
```

One Ogg/Opus file per person, written to the `recordings` volume while the
meeting is happening and put in the bucket under
`<prefix>/<meeting>/<participant>-<segment>.ogg` when it ends, after which the
local file is removed. The row in `mediacore_recording` is what a transcription
service reads: the object key, the account the token named, the offset from the
start of the meeting, and the length.

That volume is the one whose loss loses something: an `emptyDir` would drop the
audio of every meeting in progress on any restart, including the rollout that
caused it. It is separate from `persistence` because it is a different size and
a different risk -- session records are kilobytes.

### Why the SFU is a StatefulSet

Because only the process that recorded a meeting can upload it: the row in the
queue names the node the file is on. A Deployment hands every replica the same
claim, which a ReadWriteOnce volume cannot serve twice; a StatefulSet gives each
replica a volume that follows its ordinal, so a pod that comes back finds the
recordings it had not finished uploading.

It also keeps the property `strategy: Recreate` was there for. For one ordinal
the controller deletes the pod and waits for it to be gone before making the
next, so two processes never contend for the node's media port.

The volume coming back is only half of it: the replica has to come back under
the same name as well. An upload is offered only to the node whose disk holds
the file, and the server invents a fresh random `node_id` on every start unless
it is told one -- so a restart would leave the recordings sitting on the pod's
own volume claimed by a node that no longer exists, stranded for good and
counted in `stuck_recording_work`. The chart therefore sets `node_id` to the
pod's name, which for a StatefulSet is its ordinal. Set `sfu.config.node_id`
yourself only if you have something better, and never set it to a value two
replicas could share.

**The rollout that first takes this identity strands anything already on the
disk**, because those rows name the old random id. Upgrade with nothing being
recorded and `stuck_recording_work` at zero.

**Upgrading from 0.3.x DESTROYS the old volumes. Drain before you do it.**
The volumes move from standalone PVCs to `volumeClaimTemplates`, which name
themselves after the ordinal: `records-<release>-mediacore-sfu-0` and
`recordings-<release>-mediacore-sfu-0`. The old `<release>-mediacore-sfu` and
`<release>-mediacore-sfu-recordings` were objects of the release, and this
version does not declare them any more -- so Helm deletes them, and everything
on them goes at the same moment the new empty ones are provisioned. Audio that
had not reached the bucket yet is gone, and there is nothing to recover it from.

So: end the meetings, wait for `unwritten_recordings=0` and for the recording
directory to be empty, and only then upgrade. If you need the old volumes kept,
annotate the two claims with `helm.sh/resource-policy: keep` *before* upgrading;
Helm then leaves them behind for you to copy from and delete by hand.

Claims made by `volumeClaimTemplates` do not have this problem -- Kubernetes
never deletes them with the StatefulSet -- but they are immutable in exchange:
changing a size or a class needs the StatefulSet deleted with
`--cascade=orphan` and recreated around its pods.

## The server's config

The SFU reads a YAML file, not a pile of environment variables, so `sfu.config`
is that file in the server's own key names — `config-sample.yaml` in the
mediacore repository reads as documentation for it. The chart owns the parts
that must agree with the pod: `keys`, `port`, `bind_addresses`, `rtc.udp_port`,
`rtc.bind_address`, `rtc.advertise_addresses` and the two guessing switches.

`crates/config/src/lib.rs` is declared with serde's `deny_unknown_fields`: one
key it does not recognise and the process exits at startup. `values.schema.json`
mirrors that struct, so a typo is refused by helm, naming the key:

```console
$ helm template ... --set sfu.config.room.empty_timout=10
Error: values don't meet the specifications of the schema(s) in the following chart(s):
mediacore:
- at '/sfu/config/room': additional properties 'empty_timout' not allowed
```

When mediacore gains a setting, add it to `values.schema.json` in the same
change, or the chart will refuse a key the server now accepts.

## Offering clients a relay

A client whose network will not carry UDP to the media port reaches this server through
a TURN relay or not at all, and without one it fails in the worst way available: it
joins, the roster is right, the mute button works, and the room is silent. This server
runs no relay of its own -- it is ice-lite, so a relayed packet is one more source
address and nothing on the media path changes -- but it has to tell clients where one
is, and nothing else does that for it.

```yaml
auth:
  # coturn's static-auth-secret, byte for byte.
  turnSecret: <the same secret coturn was started with>
sfu:
  config:
    rtc:
      ice_servers:
        - urls:
            - turns:turn.example.com:443?transport=tcp
            - turn:turn.example.com:3478?transport=udp
          secret: ${MEDIACORE_TURN_SECRET}
          ttl_seconds: 86400
```

The secret is written as a variable and stays one. It reaches the ConfigMap as those
sixteen characters and never as its value; the server fills it in as it reads its own
config, out of an environment variable this chart takes from the Secret. A password in a
ConfigMap is a password in `helm get values` and in every `kubectl describe` of it.

With `secret`, the server mints a credential for each person as they join -- coturn's
`use-auth-secret` mode, the username carrying the expiry and the identity -- so coturn's
own logs and per-user limits name who holds an allocation, and a leaked credential is
bandwidth through one relay under one name until it expires. `username` and `credential`
instead are a fixed pair from coturn's user database: simpler, and a password that every
client that ever joins is handed.

Two things that fail as silence, both worth reading twice:

**The relay has to reach the address this server advertises.** coturn opens a socket
towards whatever is in the ICE candidates, on the client's behalf. A relay outside the
cluster while `sfu.advertise` names a node address gives a call that connects, an
allocation that succeeds, and a room where nobody hears anybody -- indistinguishable
from everyone being muted, and strictly worse than offering no relay at all.

**`turn:3478/udp` alone does not cure the case you built it for.** A network that drops
UDP to the media port usually drops UDP to 3478 as well; what reaches those people is
`turns:` on 443, which looks like ordinary HTTPS. Offer both -- a client that can go
direct never uses either, because host candidates outrank relay ones.

`ttl_seconds` has to outlive the longest call rather than the join: coturn checks the
expiry when the allocation is made and again on every refresh, so a short one takes the
relay away mid-sentence.

## Monitoring

The SFU answers `/metrics` on the signalling port in the Prometheus text format, beside `/healthz`,
and needs nothing switched on in the server to do it. The document is counts plus the node's own id,
version and region — no room, participant or track name appears in it — so a scrape needs no token
and leaks no meeting names.

```yaml
sfu:
  metrics:
    serviceMonitor:
      enabled: true
    prometheusRule:
      enabled: true
```

Both need the Prometheus operator's CRDs, and both refuse to render without them rather than
installing an object no controller reads. That refusal is right under `helm install` and under Flux,
where Helm can ask the cluster what it has; rendering offline, say so yourself with
`helm template --api-versions monitoring.coreos.com/v1`.

Ten rules ship with `defaultRules`. They are deliberately all of one kind — something that costs
data and is invisible in the logs at default level:

| Alert | Fires on |
|---|---|
| `MediacoreNodeDown` | the scrape target has been silent for five minutes |
| `MediacoreSessionStoreDown` | calls are carried and nothing about them is recorded |
| `MediacoreRecorderStopped` | this node is meant to record and its writer thread is gone |
| `MediacoreDroppingAudio` | the disk is not keeping up, so recorded audio is being thrown away |
| `MediacoreAbandonedRecordings` | a publisher's stream made the writer give up on one recording |
| `MediacoreUnwrittenSessions` | meetings held that will not be there to look up tomorrow |
| `MediacoreUndeliveredEvents` | something outside this server is missing events for good |
| `MediacoreStuckRecordingWork` | queued recording work no node will ever pick up |
| `MediacoreClusterNodeLost` | a node stopped without taking its registry row away |
| `MediacoreDrainingTooLong` | a node has been letting go of its rooms for half an hour |

There is nothing here about participant counts, packet rates or cpu. Those are dashboards: a
threshold on them would be this chart guessing at your capacity, and a guess that fires is an alert
people learn to close.

`tests/alerts_test.yaml` unit-tests the rules with `promtool test rules`. Nothing runs it for you.
Its negative cases are the useful half — a node that was never asked to record, a whole cluster that
is up, a backlog that came back down, and a failure counter that rose once an hour ago — because
each of those is a way to write an alert that is always on, and an alert that is always on is one
nobody reads.

## Checking it works

```console
kubectl logs deploy/<release>-mediacore-sfu | grep "media transport ready"
kubectl logs deploy/<release>-mediacore-front | grep listening
curl -s https://meet.example.com/healthz          # -> ok        (front end)
kubectl port-forward svc/<release>-mediacore-sfu 7880:7880
curl -s 127.0.0.1:7880/healthz                    # -> counters  (the SFU)
```

Then the real test, which needs two devices: both open the URL, join, and
speak. `rtp_packets` in the SFU's `/healthz` climbs while someone is talking.
Two tabs on one machine prove less than you would like — they can succeed on a
candidate nobody else can use.

If people join and the room is silent, it is the advertised address or a
firewall, and the SFU's log looks the same for both. Tell them apart from the
node: `tcpdump -ni any udp port 7882` while somebody presses Join. Nothing
arriving is a firewall; packets arriving while the SFU logs nothing means they
are not reaching the pod. `deploy/README.md` in the mediacore repository walks
through the same three failures in more detail.

## What this chart deliberately does not do

- **No Ingress by default.** The cluster this chart comes from is on Gateway
  API. `ingress.enabled` is there for clusters that are not, and media goes
  through neither of them.
- **No `Certificate` by default.** The wildcards already exist, and a second
  order for a name that is already certified is a way to lose a working Secret.
- **No PersistentVolumeClaim.** mediacore writes nothing to disk today, which is
  also why a restart ends every call. Session records and recordings are being
  designed and will need a volume; there is a commented placeholder in
  `values.yaml` for when they land, and an empty PVC before then would store
  nothing while making the SFU harder to schedule.
- **No autoscaling and no PodDisruptionBudget.** Both assume more than one
  replica.
- **No TURN.** A client that can only reach the world over TCP 443 cannot join;
  there is no relay in this deployment and the chart cannot invent one.
